CREATE TRIGGER AUTO_GENERATE_PK
BEFORE INSERT
  ON EMPLOYEE
FOR EACH ROW WHEN (FOR EACH ROW )
declare
  pk number;
begin
  select seq_employee.nextval into pk from dual;
   if inserting then
     :NEW.empno := pk;
   end if;
end auto_generate_pk;
/
