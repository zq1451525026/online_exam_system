CREATE function isin_balance (sal salgrade.losal%type)
   return varchar2
   is
   v_losal salgrade.losal%type;
    v_hisal salgrade.losal%type;
 begin
      select min(losal)into v_losal from salgrade;
      select max(hisal) into v_hisal from salgrade;
      if sal>v_losal and sal <  v_hisal then
           return '在正常工资范围！';
      else
           return '不在正常工资范围！';
      end if ;
 end;
/
