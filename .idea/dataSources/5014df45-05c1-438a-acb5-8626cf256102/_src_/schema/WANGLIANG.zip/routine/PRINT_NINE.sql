CREATE procedure print_nine
is
begin

   FOR i IN 1..9 LOOP
      FOR j IN 1..i LOOP  --输出每一行
	     dbms_output.put(i||'*'||j||'='||(i*j)||'  ');
	  END LOOP;
	  dbms_output.new_line; --换行
   END LOOP;
end print_nine;
/
