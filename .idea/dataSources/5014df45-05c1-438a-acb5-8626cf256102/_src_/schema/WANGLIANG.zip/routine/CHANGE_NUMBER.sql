CREATE procedure change_number(a in int,b in int)
is
    i int:=a;
    j int:=b;
    k int :=0;
begin
  dbms_output.put_line('交换前的数字为'||i||'和'||j);
  k:=i;
  i:=j;
  j:=k;
  dbms_output.put_line('交换前的数字为'||i||'和'||j);
end change_number;
/
