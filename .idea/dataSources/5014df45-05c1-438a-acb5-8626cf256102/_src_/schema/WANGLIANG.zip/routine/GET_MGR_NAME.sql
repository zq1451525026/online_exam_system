CREATE function get_mgr_name(p_mgr employee.mgr%type)
    return varchar2
is
    mgr_name employee.ename%type;
begin
    select ename into mgr_name from employee where empno = p_mgr;
    return mgr_name;
    exception
     when no_data_found then
       return null;
     when others then
       return null;

end get_mgr_name;
/
