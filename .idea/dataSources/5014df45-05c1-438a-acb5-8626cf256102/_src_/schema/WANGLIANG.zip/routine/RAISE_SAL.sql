CREATE procedure Raise_Sal(p_ename in employee.ename%type)
is
begin
  for e in (select * from employee) loop
    if e.ename = p_ename then
      dbms_output.put_line('已经为员工'||e.ename||'加薪');
      update employee set sal = sal*1.1 where ename = p_ename;
    end if;
    if MONTHS_BETWEEN(sysdate,e.hiredate)<60 then
      update employee set sal = sal+3000 where ename = p_ename;
    end if;
  end loop;
end Raise_Sal;

declare
p_ename employee.ename%type:='ANDY';
begin
  for e
  Raise_Sal(employee.ename);
end;
/
