CREATE function get_balance(p_acctno accounts.acct_no%type)
  return number
is
  g_balance number(7,2) := 0.00;
begin
  select blance into g_balance from accounts where acct_no = p_acctno;
  return g_balance;
  exception
    when others then
      dbms_output.put_line('查询的用户不存在');
end get_balance;
/
