CREATE function get_empavg(v_deptno employee.deptno%type)
return number
is
p_sal employee.sal%type;
begin
  select avg(sal) into p_sal from employee where deptno = v_deptno;
  return p_sal;
end get_empavg;
/
