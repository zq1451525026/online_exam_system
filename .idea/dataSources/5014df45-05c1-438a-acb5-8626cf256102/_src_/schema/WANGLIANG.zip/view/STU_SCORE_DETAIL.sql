CREATE VIEW STU_SCORE_DETAIL AS select st.sname,c.cname,sc.grade,t.tname
	   from student st,score sc,course c,teacher t
	where st.sno=sc.sno and sc.cno=c.cno and c.tno=t.tno
/
