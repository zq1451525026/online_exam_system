CREATE VIEW VW_DEMO AS SELECT d.dname 部门,
    d.deptno 部门号,
    s.empnum 部门员工数,
    s.avgsal 部门平均工资,
    e.ename 部门最低工资雇员,
    s.minsal 部门最低工资,
    g.grade 工资等级
  FROM department d,
       (SELECT deptno,count(empno) empnum ,AVG(sal) avgsal,MIN(sal) minsal
          FROM employee GROUP BY deptno
       ) s,
       employee e,
       salgrade g
  where d.deptno=s.deptno
     AND e.sal=s.minsal
     AND e.sal between g.losal AND g.hisal
/
